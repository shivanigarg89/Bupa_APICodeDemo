﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace SOAPService
{
    /// <summary>
    /// Summary description for SOAPDemo
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class SOAPDemo : System.Web.Services.WebService
    {
        static List<User> lstUser = new List<User>();

        [WebMethod]
        public List<User> GetUserData()
        {
            return SOAPDemo.lstUser;
        }

        [WebMethod]
        public string PostUserData(int id ,string name , int age)
        {
            User obj = new User() { id=id,age=age,name=name};
            SOAPDemo.lstUser.Add(obj);

            return "User :" + name + "is added to the list";
        }
    }
}
