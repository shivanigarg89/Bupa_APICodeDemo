using UserMaintenanceAPI.Controllers;
using UserMaintenanceAPI.Service;
using UserMaintenanceAPI.Model;
using NSubstitute;
using Microsoft.AspNetCore.Mvc;

namespace UserMaintenanceTest
{
    public class UserControllerTests
    {

        UserController _userCont;
        string nullMessage = "User details are null";
        string badReqMessage = "User Id cannot be 0";
        IUserService _userService = Substitute.For<IUserService>();

        User nullUser = null;
        User nullUserDetails = new User();

        User validUser = new User()
        {
            id = 1, name = "Paula" , age = "3",gender= "Female"
        };

        public UserControllerTests()
        {
            _userCont = new UserController(_userService);
        }

        #region check nulls
        [Fact]
        public void AddUserDetails_CheckInputForNull_BadRequest()
        {
            var result = _userCont.AddUserDetails(nullUser);
            Assert.Equal(((ObjectResult)result).Value, nullMessage);
        }

        [Fact]
        public void UpdateUserDetails_CheckInputForNull_BadRequest()
        {
            var result = _userCont.UpdateUserDetails(nullUser);
            Assert.Equal(((ObjectResult)result).Value, nullMessage);
        }

        [Fact]
        public void DeleteUserDetails_CheckInputForNull_BadRequest()
        {
            var result = _userCont.DeleteUserDetails(nullUser);
            Assert.Equal(((ObjectResult)result).Value, nullMessage);
        }
        #endregion

        #region Userdetails id and name is null or empty

        [Fact]
        public void AddUserDetails_CheckUserDetailForNull_BadRequest()
        {
            
            var result = _userCont.AddUserDetails(nullUserDetails);
            Assert.Equal(((ObjectResult)result).Value, badReqMessage);
        }

        [Fact]
        public void UpdateUserDetails_CheckUserDetailForNull_BadRequest()
        {

            var result = _userCont.UpdateUserDetails(nullUserDetails);
            Assert.Equal(((ObjectResult)result).Value, badReqMessage);
        }

        [Fact]
        public void DeleteUserDetails_CheckUserDetailForNull_BadRequest()
        {

            var result = _userCont.DeleteUserDetails(nullUserDetails);
            Assert.Equal(((ObjectResult)result).Value, badReqMessage);
        }

        #endregion

        #region GetUserDetails 

        [Fact]
        public void GetUserDetails_CheckUserDetail_Ok()
        {

            var result = _userCont.GetUserDetails();
            Assert.Equal(((ObjectResult)result).StatusCode, 200);
        }

        #endregion 
        #region AddUserDetails add user and already exists 

        [Fact]
        public void AddUserDetails_CheckUserDetailForValid_Ok()
        {

            var result = _userCont.AddUserDetails(validUser);
            Assert.Equal(((ObjectResult)result).StatusCode, 200);
        }

        [Fact]
        public void AddUserDetails_CheckUserDetailForValid_AlreadyExists()
        {
            UserService objService = new UserService();
            objService.lstUser.Add(validUser);
            _userCont = new UserController(objService);
            var result = _userCont.AddUserDetails(validUser);

            Assert.Equal(((ObjectResult)result).StatusCode, 400);
        }


        #endregion

        #region UpdateUserDetails update user and doesn't exists

        [Fact]
        public void UpdateUserDetails_validUserDetail_Ok()
        {
            //add service with a user
            UserService objService = new UserService();
            objService.lstUser.Add(validUser);
            _userCont = new UserController(objService);
            //update the existing user details
            validUser.name = "Shivani";
            var result = _userCont.UpdateUserDetails(validUser);
            Assert.Equal(((ObjectResult)result).StatusCode, 200);
            
        }


        [Fact]
        public void UpdateUserDetails_UserDetailDoesNotExists_BadRequest()
        {

            var result = _userCont.UpdateUserDetails(validUser);
            Assert.Equal(((ObjectResult)result).StatusCode, 400);
        }

        #endregion


        #region DeleteUserDetails delete user and doesn't exists

        [Fact]
        public void DeleteUserDetails_DeleteUserDetail_Ok()
        {
            //add service with a user
            UserService objService = new UserService();
            objService.lstUser.Add(validUser);
            _userCont = new UserController(objService);

            //Delete the existing user
            var  result = _userCont.DeleteUserDetails(validUser);
             Assert.Equal(((ObjectResult)result).StatusCode, 200);
            
        }

        [Fact]
        public void DeleteUserDetails_DeleteUserDetail_NotExists()
        {

            var result = _userCont.DeleteUserDetails(validUser);
            Assert.Equal(((ObjectResult)result).StatusCode, 400);
        }

        #endregion
    }
}