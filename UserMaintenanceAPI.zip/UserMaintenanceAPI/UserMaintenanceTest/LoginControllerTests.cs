﻿using UserMaintenanceAPI.Controllers;
using UserMaintenanceAPI.Service;
using UserMaintenanceAPI.Model;
using NSubstitute;
using Microsoft.AspNetCore.Mvc;
using UserMaintenanceAPI.Authentication;
using Microsoft.Extensions.Configuration;

namespace UserMaintenanceTest
{
    public class LoginControllerTests
    {
        LoginController _loginController;

         IRegisteredUser _registeredUser = Substitute.For<IRegisteredUser>();
        IConfiguration _config = Substitute.For<IConfiguration>();
        Login validLogin = new Login()
        {
            UserName = "Jack",
            Password = "Jack_01"
        };
        Login invalidLogin = new Login()
        {
            UserName = "ABC",
            Password = "ABC"
        };

        public LoginControllerTests( )
        {
            _loginController = new LoginController(_config,_registeredUser);
        }

        [Fact]
        public void Login_CheckForValidUser_Ok()
        {
            RegisteredUser objReg = new RegisteredUser();
            _loginController = new LoginController(_config,objReg);
            var result = _loginController.Login(validLogin);
            Assert.Equal(((ObjectResult)result).StatusCode, 200);
        }


        [Fact]
        public void Login_CheckForInValidUser_NotFound()
        {
            var result = _loginController.Login(invalidLogin);
            Assert.Equal(((ObjectResult)result).StatusCode, 404);
        }
    }
}
