﻿namespace UserMaintenanceAPI.Authentication
{
    public class RegisteredUser :IRegisteredUser
    {
        List<UserLogin> listRegisteredUser;

        public RegisteredUser()
        {
            listRegisteredUser = new List<UserLogin>();
            UserLogin obj = new UserLogin();
            UserLogin obj1 = new UserLogin();
            obj.UserName = "Jack";
            obj.Password = "Jack_01";
            obj.Email = "Jack@abc.com";
            obj.Role = "Admin";
            listRegisteredUser.Add(obj);
            obj1.UserName = "John";
            obj1.Password = "John_01";
            obj1.Email = "John@abc.com";
            obj1.Role = "User";
            listRegisteredUser.Add(obj1);
        }

        public UserLogin Authenticate(Login objLogin)
        {
            UserLogin objLoggedInUser = listRegisteredUser.FirstOrDefault(
                predicate: i =>i.UserName.ToLower() == objLogin.UserName.ToLower() 
                && i.Password.ToLower() == objLogin.Password.ToLower()  );

            if(objLoggedInUser != null)
                return objLoggedInUser;

            return null;
            
        }
    }
}
