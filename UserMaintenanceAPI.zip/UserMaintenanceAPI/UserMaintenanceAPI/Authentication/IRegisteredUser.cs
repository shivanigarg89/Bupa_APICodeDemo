﻿namespace UserMaintenanceAPI.Authentication
{
    public interface IRegisteredUser
    {
        UserLogin Authenticate(Login objLogin);
    }
}
