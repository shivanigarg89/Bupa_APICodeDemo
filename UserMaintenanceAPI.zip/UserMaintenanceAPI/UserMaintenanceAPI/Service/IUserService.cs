﻿using UserMaintenanceAPI.Model;

namespace UserMaintenanceAPI.Service
{
    public interface IUserService
    {
        List<User> getUserList();
        User getUserById(int id);
        void addUser(User user);
        void updateUser(User user);
        bool deleteUser(User user);


    }
}
