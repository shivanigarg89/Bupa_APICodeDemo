﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using UserMaintenanceAPI.Model;

namespace UserMaintenanceAPI.Service
{
    public class ExceptionFilterService:IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            var errorMessage = new ErrorMessage()
            {
                StatusCode = 500,
                Message = "Something went wrong , Internal Server Error!!"
            };
            
            context.Result = new JsonResult(errorMessage);
            
        }

    }
    
}
