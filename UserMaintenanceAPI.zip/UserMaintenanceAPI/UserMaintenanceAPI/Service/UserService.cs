﻿using UserMaintenanceAPI.Model;

namespace UserMaintenanceAPI.Service
{
    public class UserService:IUserService
    {
        public List<User> lstUser;

        public UserService()
        {
            lstUser = new List<User>();
        }
        public List<User> getUserList()
        {
            return lstUser.ToList();
        }
       public User getUserById(int id)
        {
            User user = new User();
            user = lstUser.FirstOrDefault(i => i.id == id);
            return user;
        }

        public void addUser(User user)
        {
            lstUser.Add(user);
        }

        public void updateUser(User user)
        {
            foreach (var userObj in lstUser)
            {
                if(userObj.id == user.id)
                {
                    userObj.name = user.name;
                    userObj.age = user.age;
                    userObj.gender = user.gender;
                }
            }
        }

        public bool deleteUser(User user)
        {
            
            var i = lstUser.FindIndex( x => x.id == user.id);
           
                lstUser.RemoveAt(i);
            return true;
        }


    }
}
