﻿using Microsoft.AspNetCore.Mvc;
using UserMaintenanceAPI.Service;
using UserMaintenanceAPI.Model;
using Microsoft.AspNetCore.Authorization;

namespace UserMaintenanceAPI.Controllers
{
    [TypeFilter(typeof(ExceptionFilterService))]
    [ApiController]
    [Route("[controller]")]
    public class UserController : Controller
    {

        IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;     
        }


        // Get controller to get list of users
        [HttpGet("GetUserDetails.{format}") , FormatFilter]
        public IActionResult GetUserDetails()
        {
            try
            {
                List<User> result = _userService.getUserList();
                return Ok(result);
            }catch(Exception ex)
            {
                throw ex;
            }
        }


        [HttpPost ("AddUserDetails.{format}"), FormatFilter]
        [Authorize(Roles ="Admin")]
        public IActionResult AddUserDetails([FromBody]  User user)
        {
            try
            {
                //check request body is not null and id is not 0
                if (user == null)
                    return BadRequest("User details are null");
                if (user.id == 0)
                    return BadRequest("User Id cannot be 0");
                else
                {
                    //check if user already exists dont add the same record
                    User exitinguser = _userService.getUserById(user.id);
                    if (exitinguser == null)
                    {
                        _userService.addUser(user);
                        return Ok("User Added");
                    }
                    else
                    {
                        return BadRequest("User already exists in system");
                    }
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }


        [HttpPut("UpdateUserDetails.{format}"), FormatFilter]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateUserDetails([FromBody] User user)
        {
            try
            {
                //check request body is not null and id is not 0
                if (user == null)
                    return BadRequest("User details are null");
                if (user.id == 0)
                    return BadRequest("User Id cannot be 0");
                else
                {
                    // check if user exists then only we can update the record
                    User exitinguser = _userService.getUserById(user.id);
                    if (exitinguser == null)
                    {
                        return BadRequest("User does not exists in system");
                    }
                    else
                    {
                        _userService.updateUser(user);
                        return Ok("User Updated Succesfully");
                    }
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }

        }


        [HttpDelete("DeleteUserDetails.{format}"), FormatFilter]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteUserDetails(User user)
        {
            try
            {
                //check request body is not null and id is not 0
                if (user == null)
                    return BadRequest("User details are null");
                if (user.id == 0)
                    return BadRequest("User Id cannot be 0");
                else
                {
                    // check if user exists then only we can delete the record
                    User exitinguser = _userService.getUserById(user.id);
                    if (exitinguser == null)
                    {
                        return BadRequest("User does not exists in system");
                    }
                    else
                    {
                        bool result = _userService.deleteUser(user);
                        return Ok("User Deleted Succesfully");
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet("CheckException")]
        public IActionResult CheckException()
        {
            
            throw new NotImplementedException();
               
        }
    
    }
}
