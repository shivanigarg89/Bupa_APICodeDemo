﻿using System.ComponentModel.DataAnnotations;

namespace UserMaintenanceAPI.Model
{
    public class User
    {
        [Required]
        public int id { get; set; }

        [Required]
        public string name { get; set; }
        public string age { get; set; }
        public string gender { get; set; }
    }
}
