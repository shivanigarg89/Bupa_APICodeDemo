﻿namespace UserMaintenanceAPI.Model
{
    public class ErrorMessage
    {
        public int StatusCode { get;set; }
        public string Message { get; set; }
    }
}
